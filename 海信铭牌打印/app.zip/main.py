import wx
import pandas as pd
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Image
from reportlab.lib import colors
import qrcode

# Load excel data into pandas dataframe
df = pd.read_excel('海信物料编码.xlsx', engine='openpyxl')

class ProductSearchApp(wx.Frame):

    def __init__(self, parent):
        super(ProductSearchApp, self).__init__(parent)

        self.initUI()

    def initUI(self):
        panel = wx.Panel(self)

        vbox = wx.BoxSizer(wx.VERTICAL)

        hbox1 = wx.BoxSizer(wx.HORIZONTAL)
        st1 = wx.StaticText(panel, label='Product Name:')
        hbox1.Add(st1, flag=wx.RIGHT, border=8)
        self.product_name_tc = wx.TextCtrl(panel)
        hbox1.Add(self.product_name_tc, proportion=1)
        vbox.Add(hbox1, flag=wx.EXPAND|wx.LEFT|wx.RIGHT|wx.TOP, border=10)

        vbox.Add((-1, 10))

        hbox2 = wx.BoxSizer(wx.HORIZONTAL)
        st2 = wx.StaticText(panel, label='Quantity:')
        hbox2.Add(st2)
        self.quantity_tc = wx.TextCtrl(panel)
        hbox2.Add(self.quantity_tc, proportion=1)
        vbox.Add(hbox2, flag=wx.EXPAND|wx.LEFT|wx.RIGHT|wx.TOP, border=10)

        vbox.Add((-1, 10))

        hbox3 = wx.BoxSizer(wx.HORIZONTAL)
        btn = wx.Button(panel, label='Search', size=(70, 30))
        btn.Bind(wx.EVT_BUTTON, self.onSearch)
        hbox3.Add(btn)
        vbox.Add(hbox3, flag=wx.ALIGN_RIGHT|wx.RIGHT, border=10)

        panel.SetSizer(vbox)

    def onSearch(self, event):
        product_name = int(self.product_name_tc.GetValue())
        print(product_name)
        quantity = self.quantity_tc.GetValue()
        product = df[df['物料编码'] == product_name]
        print(df['物料编码'])
        if not product.empty:
            # Show product info
            wx.MessageBox(product.to_string(), "批次")

            # Generate QR code with product description
            product_info = str(product['物料编码'].values[0])  # Convert description to string
            qr_code = qrcode.make(product_info)

            # Save QR code to file
            qr_code_file = "qr_code.png"
            qr_code.save(qr_code_file)

            # Generate QR code for quantity
            qr_code_quantity = qrcode.make(quantity)

            # Save QR code to file
            qr_code_file_quantity = "qr_code_quantity.png"
            qr_code_quantity.save(qr_code_file_quantity)  # Use qr_code_quantity here

            # Generate a PDF with product info and QR code
            doc = SimpleDocTemplate("product_label.pdf", pagesize=letter)

            # create table with product info
            data = [
                ["Product", "Quantity", "QR Code","Quantity"],
                [product_name, quantity, Image(qr_code_file),Image(qr_code_file_quantity)]
            ]

            table = Table(data)

            # add style
            style = TableStyle([
                ('BACKGROUND', (0,0), (-1,0), colors.grey),
                ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),

                ('ALIGN', (0,0), (-1,-1), 'CENTER'),
                ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
                ('FONTSIZE', (0,0), (-1,0), 14),

                ('BOTTOMPADDING', (0,0), (-1,0), 12),
                ('BACKGROUND', (0,1), (-1,-1), colors.beige),
                ('GRID', (0,0), (-1,-1), 1, colors.black)
            ])
            table.setStyle(style)

            # add table to elements to be added to pdf
            elems = []
            elems.append(table)

            # build pdf
            doc.build(elems)

        else:
            wx.MessageBox("Product not found", "Error")

app = wx.App()
ProductSearchApp(None).Show()
app.MainLoop()
