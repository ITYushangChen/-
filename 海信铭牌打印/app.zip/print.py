import win32print
default_printer = win32print.GetDefaultPrinter()
print(f"Default printer is: {default_printer}")
