import wx
import pandas as pd
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Image
from reportlab.lib import colors
from PyPDF2 import PdfWriter, PdfReader
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import qrcode
import io
import os
import subprocess
import win32print
import win32api

# Function to load data
def load_data():
    df = pd.read_excel('海信物料编码.xlsx', engine='openpyxl')
    return df

# Function to generate QR code
def generate_qr(data, filename):
    qr_code = qrcode.make(data)
    qr_code.save(filename)
    return filename

class ProductSearchApp(wx.Frame):
    def __init__(self, parent):
        super(ProductSearchApp, self).__init__(parent)
        self.df = load_data()
        self.initUI()

    def initUI(self):
        panel = wx.Panel(self)

        vbox = wx.BoxSizer(wx.VERTICAL)

        hbox1 = wx.BoxSizer(wx.HORIZONTAL)
        st1 = wx.StaticText(panel, label='Product Name:')
        hbox1.Add(st1, flag=wx.RIGHT, border=8)
        self.product_name_tc = wx.TextCtrl(panel)
        hbox1.Add(self.product_name_tc, proportion=1)
        vbox.Add(hbox1, flag=wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, border=10)

        vbox.Add((-1, 10))

        hbox2 = wx.BoxSizer(wx.HORIZONTAL)
        st2 = wx.StaticText(panel, label='Quantity:')
        hbox2.Add(st2)
        self.quantity_tc = wx.TextCtrl(panel)
        hbox2.Add(self.quantity_tc, proportion=1)
        vbox.Add(hbox2, flag=wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, border=10)

        vbox.Add((-1, 10))

        hbox3 = wx.BoxSizer(wx.HORIZONTAL)
        btn1 = wx.Button(panel, label='Search', size=(70, 30))
        btn1.Bind(wx.EVT_BUTTON, self.onSearch)
        hbox3.Add(btn1)
        btn2 = wx.Button(panel, label='Print', size=(70, 30))
        btn2.Bind(wx.EVT_BUTTON, self.onPrint)
        hbox3.Add(btn2)
        vbox.Add(hbox3, flag=wx.ALIGN_RIGHT | wx.RIGHT, border=10)

        panel.SetSizer(vbox)

    # def print_pdf(self, printer_name, file_name, times):
    #     hPrinter = win32print.OpenPrinter(printer_name)
    #     try:
    #         hJob = win32print.StartDocPrinter(hPrinter, 1, ("test of raw data", None, "RAW"))
    #         try:
    #             with open(file_name, "rb") as f:
    #                 data = f.read()
    #                 for i in range(0, times):
    #                     win32print.WritePrinter(hPrinter, data)
    #         finally:
    #             win32print.EndDocPrinter(hPrinter)
    #     finally:
    #         win32print.ClosePrinter(hPrinter)
    #
    # def onPrint(self, event):
    #     quantity = int(self.quantity_tc.GetValue())
    #     printer_name = win32print.GetDefaultPrinter()  # 获取默认打印机
    #     pdf_path = 'output.pdf'  # 例如: '/Users/username/Documents/pdf_folder'
    #     self.print_pdf(printer_name, pdf_path, quantity)
# C:\Program Files\gs\gs10.01.2
#     def onPrint(self, event):
#         quantity = int(self.quantity_tc.GetValue())
#         printer_name = win32print.GetDefaultPrinter()  # 获取默认打印机
#         pdf_path = 'Assignment.pdf'  # 例如: '/Users/username/Documents/pdf_folder'
#         GHOSTSCRIPT_PATH = r'C:\Program Files\gs\gs10.01.2\bin\gswin64c.exe'
#
#         # 循环打印
#         for i in range(quantity):
#             print("here")
#             subprocess.call(f'"{GHOSTSCRIPT_PATH}" -dBATCH -dNOPAUSE -sDEVICE=mswinpr2 -sOutputFile="%printer%{printer_name}" "{pdf_path}"', shell=True)
#             print("11111")
    def onPrint(self, event):
        print("printing..................")
        quantity = int(self.quantity_tc.GetValue())  # 获取用户输入的打印数量
        for _ in range(quantity):  # 循环打印
            open("output.pdf", 'r')
            win32api.ShellExecute(
                0,
                "print",
                "output.pdf",
                '/d:"%s"' % win32print.GetDefaultPrinter(),
                ".",
                0
            )
    def onSearch(self, event):
        product_name = int(self.product_name_tc.GetValue())
        quantity = self.quantity_tc.GetValue()
        product = self.df[self.df['物料编码'] == product_name]

        if not product.empty:
            wx.MessageBox(product.to_string(), "批次")
            code_wuliao = str(product['物料编码'].values[0])
            description = str(product['物料描述'].values[0])
            code_gongfang = str(product['供方代码'].values[0])
            qr_code_file = generate_qr(str(product['物料编码'].values[0]), 'qr_code.png')
            qr_code_file_quantity = generate_qr(quantity, 'qr_code_quantity.png')

            with open('初始.pdf', 'rb') as f:
                source = PdfReader(f)
                page = source.pages[0]
                pdfmetrics.registerFont(TTFont('SimHei', 'SimHei.ttf'))
                packet = io.BytesIO()
                c = canvas.Canvas(packet, pagesize=page.mediabox.upper_right)
                print(description)
                c.setFont('Helvetica', 100)
                c.drawString(1000, 1530, code_wuliao)
                c.drawString(1200, 1250, str(product_name))

                c.drawString(2300, 1250, "2019/11/20")
                c.drawString(1200, 670, "2019/11/20")
                c.drawString(1200, 420, str(quantity))
                c.drawString(650, 100, "gongfang")
                c.drawImage(qr_code_file, 20, 600, width=550, height=550)
                c.drawImage(qr_code_file_quantity, 2270, 100, width=550, height=550)
                c.setFont('SimHei', 100)
                c.drawString(1200, 970, description)

                c.save()
                packet.seek(0)
                new_pdf = PdfReader(packet)
                page.merge_page(new_pdf.pages[0])
                output = PdfWriter()
                output.add_page(page)
                with open('output.pdf', 'wb') as f:
                    output.write(f)

        else:
            wx.MessageBox("Product not found", "Error")

app = wx.App()
ProductSearchApp(None).Show()
app.MainLoop()
