import wx
import pandas as pd
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Image
from reportlab.lib import colors
from PyPDF2 import PdfWriter, PdfReader
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import qrcode
import io
import os
import subprocess
import win32print
import win32api
from datetime import datetime
import time
# 获取当前日期
current_date = datetime.now()

# 以year/month/day的格式输出
DATE = current_date.strftime("%Y/%m/%d")
nonSplitDate = DATE.replace("/","")
SUPPILER = "青岛开拓隆海制冷配件有限公司"
# Function to load data
def load_data():
    df = pd.read_excel('海信物料编码.xlsx', engine='openpyxl')
    return df

# Function to generate QR code
def generate_qr(data, filename):
    qr_code = qrcode.make(data)
    qr_code.save(filename)
    return filename

class ProductSearchApp(wx.Frame):
    def __init__(self, parent):
        super(ProductSearchApp, self).__init__(parent)
        self.df = load_data()
        self.product_code_list = [str(code) for code in self.df['物料编码'].unique()]  # 获取所有不重复的物料编码，并将它们转换为字符串
        self.initUI()


    def initUI(self):
        panel = wx.Panel(self)

        vbox = wx.BoxSizer(wx.VERTICAL)

        hbox1 = wx.BoxSizer(wx.HORIZONTAL)
        st1 = wx.StaticText(panel, label='物料编码:')
        hbox1.Add(st1, flag=wx.RIGHT, border=8)
        self.product_name_tc = wx.ComboBox(panel, choices=self.product_code_list, style=wx.CB_DROPDOWN | wx.CB_SORT)
        hbox1.Add(self.product_name_tc, proportion=1)
        vbox.Add(hbox1, flag=wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, border=10)

        vbox.Add((-1, 10))

        hbox2 = wx.BoxSizer(wx.HORIZONTAL)
        st2 = wx.StaticText(panel, label='批次:')
        hbox2.Add(st2)
        self.quantity_tc = wx.TextCtrl(panel)
        hbox2.Add(self.quantity_tc, proportion=1)
        vbox.Add(hbox2, flag=wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, border=10)

        vbox.Add((-1, 10))

        hbox4 = wx.BoxSizer(wx.HORIZONTAL)
        st4 = wx.StaticText(panel, label='数量/箱:')
        hbox4.Add(st4)
        self.products_per_batch_tc = wx.TextCtrl(panel)
        hbox4.Add(self.products_per_batch_tc, proportion=1)
        vbox.Add(hbox4, flag=wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, border=10)

        vbox.Add((-1, 10))

        hbox3 = wx.BoxSizer(wx.HORIZONTAL)
        btn1 = wx.Button(panel, label='添加', size=(70, 30))
        btn1.Bind(wx.EVT_BUTTON, self.onSearch)
        hbox3.Add(btn1)
        btn2 = wx.Button(panel, label='打印', size=(70, 30))
        btn2.Bind(wx.EVT_BUTTON, self.onPrint)
        hbox3.Add(btn2)
        vbox.Add(hbox3, flag=wx.ALIGN_RIGHT | wx.RIGHT, border=10)

        btn3 = wx.Button(panel, label='清除', size=(110, 30))
        btn3.Bind(wx.EVT_BUTTON, self.onDelete)
        hbox3.Add(btn3)

        panel.SetSizer(vbox)

    def onDelete(self, event):
        pdf_folder = 'pdfs'
        for pdf_file in os.listdir(pdf_folder):
            if pdf_file.endswith('.pdf'):
                os.remove(os.path.join(pdf_folder, pdf_file))
        wx.MessageBox("清除成功!", "Success", wx.OK | wx.ICON_INFORMATION)
    def onPrint(self, event):
        print("printing..................")
        pdf_files = [f for f in os.listdir(os.curdir) if f.endswith('.pdf') and f.startswith('output')]
        for pdf_file in pdf_files:
            win32api.ShellExecute(
                0,
                "print",
                pdf_file,
                '/d:"%s"' % win32print.GetDefaultPrinter(),
                ".",
                0
            )


    def onSearch(self, event):
        product_name = int(self.product_name_tc.GetValue())
        quantity = self.quantity_tc.GetValue()
        product = self.df[self.df['物料编码'] == product_name]
        products_per_batch_tc = self.products_per_batch_tc.GetValue()

        if not product.empty:
            wx.MessageBox("添加成功！", "批次")
            code_wuliao = str(product['物料编码'].values[0])
            description = str(product['物料描述'].values[0])
            code_gongying = str(product['供方代码'].values[0])
            for i in range(int(quantity)):
                with open('初始.pdf', 'rb') as f:
                    ENCODE = code_wuliao + "-" + code_gongying + "-"+ nonSplitDate + "-" + nonSplitDate+ "-" + str(i) +"-"+ "0"
                    source = PdfReader(f)
                    page = source.pages[0]
                    pdfmetrics.registerFont(TTFont('SimHei', 'SimHei.ttf'))
                    packet = io.BytesIO()
                    qr_code_file = generate_qr(ENCODE, 'qr_code.png')
                    qr_code_file_quantity = generate_qr(products_per_batch_tc, 'qr_code_quantity.png')
                    c = canvas.Canvas(packet, pagesize=page.mediabox.upper_right)
                    print(description)
                    c.setFont('Helvetica', 11)
                    c.drawString(40, 150, ENCODE)
                    c.drawString(112, 122, str(product_name))
                    c.drawString(227, 122, DATE)
                    c.drawString(112, 66, DATE)
                    c.drawString(112, 38, str(products_per_batch_tc))
                    c.setFont('SimHei', 11)
                    c.drawString(112, 94, description)
                    c.drawString(60, 10, SUPPILER)

                    c.drawImage(qr_code_file, 3, 70, width=50, height=50)
                    c.drawImage(qr_code_file_quantity, 230, 23, width=50, height=50)
                    c.save()
                    packet.seek(0)
                    new_pdf = PdfReader(packet)
                    page.merge_page(new_pdf.pages[0])
                    output = PdfWriter()
                    output.add_page(page)
                    timestamp = str(time.time()).replace('.', '')  # 获取当前时间戳并去除小数点
                    with open(f'pdfs/output_{product_name}_{timestamp}_{i}.pdf', 'wb') as f:  # 文件名中包含产品名和时间戳
                        output.write(f)


        else:
            wx.MessageBox("无效编码！", "Error")

app = wx.App()
ProductSearchApp(None).Show()
app.MainLoop()
